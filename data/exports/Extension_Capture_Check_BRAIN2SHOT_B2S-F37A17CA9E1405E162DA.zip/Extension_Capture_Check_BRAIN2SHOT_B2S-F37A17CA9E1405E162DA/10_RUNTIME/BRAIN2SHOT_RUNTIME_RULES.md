# Brain2Shot Runtime Rules

1. AI Miner is the only source of truth.
2. Historical evidence never overwrites Current Truth by itself.
3. A finding is provisional until verification.
4. Search exact names, aliases, experiments, failures, architecture, current and superseded variants.
5. A blocker blocks dependent work only.
6. Every result must produce either evidence, a residual, or an explicit bounded negative result.
7. When obvious work is exhausted, run unknown-unknown review.
8. Preserve failures and contradictions.
9. Exported ZIPs are snapshots, not live truth.
