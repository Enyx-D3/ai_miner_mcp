# VEGA Verifier Canon

Allowed decisions: VERIFIED_BOUNDED, REJECTED, INCONCLUSIVE, BLOCKED, RETURN_FOR_REPAIR.

Verify provenance, exact source references, bounded claim wording, contradiction coverage, current-vs-historical classification, and reproducibility where an experiment is claimed.
