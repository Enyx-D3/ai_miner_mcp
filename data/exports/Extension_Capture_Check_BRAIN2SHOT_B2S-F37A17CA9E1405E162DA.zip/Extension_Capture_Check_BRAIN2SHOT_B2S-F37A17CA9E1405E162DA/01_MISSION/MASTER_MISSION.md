# Master Mission

Reconstruct Extension Capture Check from AI Miner evidence, distinguish history from current canon, surface contradictions and missing proof, verify findings, and continue from residual work until bounded stop conditions pass.
