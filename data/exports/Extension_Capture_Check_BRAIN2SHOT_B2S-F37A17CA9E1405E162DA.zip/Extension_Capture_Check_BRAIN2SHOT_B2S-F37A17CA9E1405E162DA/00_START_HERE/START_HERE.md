# Brain2Shot Mission Snapshot

Source of truth: **AI Miner**.

Project: **Extension Capture Check**
Mission: `B2S-F37A17CA9E1405E162DA`
Source fingerprint: `ec9c760834a0e7d07a010968f5d062185ffa321bcdc55f03a511cf18ec044741`

This ZIP is a portable snapshot. If AI Miner is available, refresh against AI Miner before treating this snapshot as current.
